"""
Tests unitaires du module partieA.py
Chaque test unitaire est construit en préfixant la fonction testée de test_
"""
from partieA import *



## Tests unitaires de la question 7

def test_str_to_bytes():
    for chaine in ['1','a', 'A', 'é']:
        print(f'chaine (type str) : {chaine} => flux (type bytes) : {str_to_bytes(chaine)}')

def test_bytes_to_str():
    for flux in [b'1',b'a', b'A', b'\xc3\xa9']:
        print(f'flux (type bytes) : {flux} =>  chaine (type str) : {bytes_to_str(flux)}')

def test_hex_to_bytes():
    for hexadecimal in ['00', '06', '0B','A1', 'FF']:
         print(f'nombre en hexadécimal : {hexadecimal} => flux (type bytes) : {hex_to_bytes(hexadecimal)}')


# Décommentez pour tester

#test_str_to_bytes()
#test_bytes_to_str()
#test_hex_to_bytes()

## Tests unitaires de la question 8


def test_image(fichier = 'damier_2x2.png'):
    img = fichier_to_image(fichier)
    print("Représentation de l'objet image PIL", end = "\n\n")
    print(img, end = "\n\n")
    print("Pixels de l'objet image PIL", end = "\n\n")
    print(list(img.getdata()), end = "\n\n")
    print("Pixels en hadécimal de l'objet image PIL", end = "\n\n")
    print([decimal_to_hex(pixel) for pixel in list(img.getdata())], end = "\n\n")
    img_bytes = image_to_bytes(img)
    print("Affichage de l'image sous forme de flux d'octets", end = "\n\n")
    print(img_bytes, end = "\n\n")
    print("Inversion de tous les octets", end = "\n\n")
    img_bytes_sortie = b''.join([(255 - img_bytes[k]).to_bytes(1, byteorder='little') for k in range(len(img_bytes))])
    print(img_bytes_sortie, end = "\n\n")
    img_sortie = bytes_to_image(img_bytes_sortie, img.width, img.height)
    img_sortie.show()
    nom, extension = fichier.split('.')
    img_sortie.save('sortie-test-image-' + nom + '.' + extension)


test_image()