# -*- coding: utf-8 -*-

from PIL import Image

#Installation de PIL https://pillow.readthedocs.io/en/stable/installation.html


## Constantes

#chiffres en base 16
BASE_16 = '0123456789ABCDEF'


def index_premiere_occurence(element, tab):
    """
    Parametres :
        element de type quelconque (le même que les éléments de tab)
        tab un tableau d'éléments de même type
    Valeur renvoyée:
        l'indice de la première occurence de element dans tab
        None si element n'est pas dans tab
    """
    #à compléter

def decimal_to_hex(n):
    """
    Parametres :
        n de type int
    Valeur renvoyée:
        représentation de n en base 16 sous forme de chaîne de caractères
        on rajoute un 0 à gauche si un seul chiffre en base 16
    """
    rep = ''
    #à compléter    

def hex_to_decimal(hexadecimal):
    """
    Parametres :
        hexadecimal de type str représentant un entier en base 16
    Valeur renvoyée:
        représentation décimale de hexadecimal sous forme d'entier de type int
    """
    n = 0
    #à compléter   

def str_to_bytes(chaine, encodage = 'utf8'):
    """
    Paramètres :
        chaine de type str, une chaine de caractères
        encodage un paramètre de type str fixant l'encodage, par défaut utf8
    Valeur renvoyée :
        un flux d'octets de type bytes obtenu par encodage de chaine
    """
    return chaine.encode(encoding = encodage)

def bytes_to_str(flux, encodage = 'utf8'):
    """
    Paramètres :
        flux d'octets de type bytes
        encodage un paramètre de type str fixant l'encodage, par défaut utf8
    Valeur renvoyée :
        une chaine de caractères de type str obtenue par décodage de flux
    """
    return flux.decode(encoding = encodage)

def hex_to_bytes(hexadecimal):
    """
    Paramètres :
        hexadecimal de type str représentant un nombre à 2 chiffres en base 16
    Valeur renvoyée :
        un octet de type bytes représentant le même nombre qu'hexadecimal
    """
    return bytes.fromhex(hexadecimal)

def fichier_to_image(fichier):
    """
    Paramètres :
        fichier de type str qui est un chemin vers un fichier image
    Valeur renvoyée :
        objet image représentant l'image contenue dans fichier pour le module PIL
        le mode de l'image renvoyée est 'L' pour niveaux de gris (1 octet par pixel)
    """
    img = Image.open(fichier)
    img = img.convert('L')
    return img

def image_to_bytes(img):
    """
    Paramètres :
        img est un objet renvoyé par fichier_to_image représentant une image pour le module PIL
        img de mode 'L' pour niveaux de gris (1 octet par pixel)
    Valeur renvoyée :
        un flux d'octets représentant les valeurs des pixels de l'image
    """
    return bytes.fromhex(' '.join([decimal_to_hex(pixel) for pixel in list(img.getdata())]))

def bytes_to_image(flux, largeur, hauteur):
    """
    Paramètres :
        flux de type bytes  représente la séquence de valeurs des pixels d'une image en niveaux de gris
        largeur et hauteur de type int sont les dimensions de l'image
    Valeur renvoyée :
        un objet représentant une image en niveaux de gris pour le module PIL
    """
    im = Image.new( 'L', (largeur, hauteur))
    im.putdata([flux[k] for k in range(len(flux))])
    return im