

# Interface utilisateur d'un système d'exploitation : le shell

Une interface entre l'utilisateur  et le système d'exploitation s'appelle un [shell](https://fr.wikipedia.org/wiki/Shell_Unix) ou *interpréteur de commandes.

Le rôle d'un *shell* est de prendre une entrée de l'utilisateur, de la traduire en instructions compréhensibles par le système d'exploitation et de renvoyer la réponse du système à l'utilisateur.



Il existe deux grandes catégories de *shell* :

* les *interfaces textuelles* comme [bash](https://fr.wikipedia.org/wiki/Bourne-Again_shell), le plus commun sur les systèmes de la famille [UNIX](https://fr.wikipedia.org/wiki/Bourne-Again_shell).
* les *interfaces graphiques* qu'on retrouve dans les systèmes d'exploitation grand public tels que [Windows](https://fr.wikipedia.org/wiki/Microsoft_Windows)

Nous utiliserons [bash](https://fr.wikipedia.org/wiki/Bourne-Again_shell) dans ce TP et le suivant. La syntaxe d'une commande [bash](https://fr.wikipedia.org/wiki/Bourne-Again_shell) est simple : le nom de la commande peut être suivi d'options facultatives introduites par un tiret et d'arguments :
 `nom_commande -option1 -option2 argument1 argument2`.

 Par exemple, la commande ci-dessous demande d'utiliser la commande `ls` pour afficher les informations détaillées (option `_l`) sur le fichier `exemple`:

    junier@fredportable:~/bac$ ls -l exemple
    -rw-rw-r-- 1 nobody mail 0 août  16 12:05 exemple

Chaque commande est un programme enregistré dans un fichier, par exemple `/usr/bin/ls` pour la commande `ls`:

    junier@fredportable:~/bac$ which ls
    /usr/bin/ls
    junier@fredportable:~/bac$ ls -l /usr/bin/ls
    -rwxr-xr-x 1 root root 142144 sept.  5  2019 /usr/bin/ls

Enfin chaque commande possède trois flux d'entrée / sortie :

* *l'entrée standard*  qui est par défaut le clavier (les options et arguments sont traités puis transmis par [bash](https://fr.wikipedia.org/wiki/Bourne-Again_shell) sur l'entrée standard de la commande)
*  *la sortie standard* qui est par défaut  l'écran 
*  *la sortie d'erreur* qui est  par défaut l'écran également

Il existe des opérateurs `>` et `<` pour rediriger les flux d'entrée / sortie.

Considérons un exemple . La commande `ls` sans argument affiche le contenu du répertoire courant sur la sortie standard et la  commande  `cat`  renvoie son entrée standard sur sa sortie standard : 

        junier@fredportable:~/bac$ ls 
        entrée
        junier@fredportable:~/bac$ cat --help
        Utilisation : cat [OPTION]... [FICHIER]...
        Concaténer les FICHIERs vers la sortie standard.
        ............
        junier@fredportable:~/bac$ cat entrée
        contenu de entrée
        junier@fredportable:~/bac$ cat entrée > sortie
        junier@fredportable:~/bac$ ls
        entrée  sortie
        junier@fredportable:~/bac$ cat sortie
        contenu de entrée

Nous fournirons un memento des principales commandes de [bash](https://fr.wikipedia.org/wiki/Bourne-Again_shell) communes à tous la plupart des *shell* des systèmes de la famille UNIX](https://fr.wikipedia.org/wiki/Bourne-Again_shell).

Un memento en ligne :  <https://juliend.github.io/linux-cheatsheet/>