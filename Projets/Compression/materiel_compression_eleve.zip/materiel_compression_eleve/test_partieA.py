# -*- coding: utf-8 -*-
"""
Tests unitaires du module partieA.py
Chaque test unitaire est construit en préfixant la fonction testée de test_
"""
from partieA import *

#%% Tests unitaires de la question 4

def test_index_premiere_occurence():
    benchmark = [(7, [], None), (7, [7,0], 0), (7, [4,7], 1), (7, [4,7,3,7], 1), (7, [4,8], None)]
    for element, tab, reponse in benchmark:
        assert index_premiere_occurence(element, tab) == reponse
    print("Tests réussis pour index_premiere_occurence")
 
# Décommentez pour tester
# test_index_premiere_occurence()

#%% Tests unitaires de la question 5
def test_hex_to_decimal():
    benchmark = [('00', 0), ('04', 4), ('0E', 14), ('AE', 174)]
    for hexadecimal, decimal in benchmark:
        assert hex_to_decimal(hexadecimal) == decimal
    print("Tests réussis pour hex_to_decimal")

# Décommentez pour tester
# test_hex_to_decimal()

#%% Tests unitaires de la question 6
   
def test_decimal_to_hex():
    benchmark = [(7, '07'), (17, '11'), (243, 'F3'), (0, '00'), (14, '0E')]
    for decimal, hexadecimal in benchmark:
        assert decimal_to_hex(decimal) == hexadecimal
    print("Tests réussis pour decimal_to_hex")

# Décommentez pour tester
# test_decimal_to_hex()

#%% Tests unitaires de la question 7

def test_str_to_bytes():
    for chaine in ['1','a', 'A', 'é']:
        flux = str_to_bytes(chaine)
        print('chaine (type str) : {0} => flux (type bytes) : {1}'.format(chaine, flux))
    print("Tests réussis pour str_to_bytes")

def test_bytes_to_str():
    for flux in [b'1',b'a', b'A', b'\xc3\xa9']:
        chaine = bytes_to_str(flux)
        print('flux (type bytes) : {0} =>  chaine (type str) : {1}'.format(flux, chaine))
    print("Tests réussis pour bytes_to_str")


def test_hex_to_bytes():
    for hexadecimal in ['00', '06', '0B','A1', 'FF']:
        flux = hex_to_bytes(hexadecimal)
        print('nombre en hexadécimal : {0} => flux (type bytes) : {1}'.format(hexadecimal, flux))
    print("Tests réussis pour hex_to_bytes")

# Décommentez pour tester

# test_str_to_bytes()
# test_bytes_to_str()
# test_hex_to_bytes()

#%% Tests unitaires de la question 8


def test_image(fichier = 'damier_2x2.png'):
    img = fichier_to_image(fichier)
    print("Représentation de l'objet image PIL", end = "\n\n")
    print(img, end = "\n\n")
    print("Pixels de l'objet image PIL", end = "\n\n")
    print(list(img.getdata()), end = "\n\n")
    print("Pixels en hadécimal de l'objet image PIL", end = "\n\n")
    print([decimal_to_hex(pixel) for pixel in list(img.getdata())], end = "\n\n")
    img_bytes = image_to_bytes(img)
    print("Affichage de l'image sous forme de flux d'octets", end = "\n\n")
    print(img_bytes, end = "\n\n")
    print("Inversion de tous les octets", end = "\n\n")
    img_bytes_sortie = b''.join([(255 - img_bytes[k]).to_bytes(1, byteorder='little') for k in range(len(img_bytes))])
    print(img_bytes_sortie, end = "\n\n")
    img_sortie = bytes_to_image(img_bytes_sortie, img.width, img.height)
    img_sortie.show()
    nom, extension = fichier.split('.')
    img_sortie.save('sortie-test-image-' + nom + '.' + extension)

# Décommentez pour tester
#test_image()