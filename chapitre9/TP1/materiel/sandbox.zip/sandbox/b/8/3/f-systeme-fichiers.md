

# Attributs du système d'exploitation : le contrôle du système de fichiers

## Système de fichiers

Sur les supports de mémoire persistants (disques durs, clefs USB...), les informations sont regroupées par le système d'exploitation  dans des *fichiers*
qui sont organisés à travers un [système de fichiers](https://fr.wikipedia.org/wiki/Syst%C3%A8me_de_fichiers).



Dans les systèmes d'exploitation qui  respectent le standard [POSIX](https://fr.wikipedia.org/wiki/POSIX), on distingue  plusieurs catégories de fichiers :

*  *fichiers réguliers* ou *fichiers textes* qui contiennent des suites de caractères et qui sont lisibles par des humains
*  *fichiers binaires* qui sont des suites d'octets non lisibles par des humains
*  *fichiers exécutables* qui sont des programmes, ils peuvent être des fichiers textes binaires.
*  *répertoires* qui sont des listes de fichiers : ils servent de conteneur à fichiers.

Les *répertoires* pouvant contenir d'autres fichiers, un système de fichiers  [POSIX](https://fr.wikipedia.org/wiki/POSIX) possède une structure hiérarchique  qui est une  *arborescence* avec  un *répertoire racine* symbolisé par un /.

![Un exemple d'arborescence](https://www.frederic-junier.org/ISN/Architecture-HTML-CSS-Internet-2019/pages/images/arborescence.png)


Les fichiers sont repérés par leur *chemin* :

* *chemin absolu* depuis la racine : par exemple si un fichier `exemple.txt` se trouve dans le répertoire `sandbox`, contenu dans le répertoire  `maurice`, lui-même contenu dans le répertoire `home`, lui-même dans le répertoire racine, son *chemin absolu* est   `/home/maurice/sandbox/exemple.txt`

* ou *chemin relatif*  qui est relatif au *répertoire courant* ou *répertoire de travail* où l'utilisateur se trouve. Par exemple, si le répertoire courant est `maurice`, le *chemin relatif* du fichier précédent est `sandbox/exemple.txt`.
  
## Gestion des droits et permissions

Le système d'exploitation gère les *droits et permissions* sur les fichiers (dont les répertoires) pour les différents *utilisateurs*.

###  Utilisateurs et permissions


Pour un fichier, on distingue :

* trois types d'utilisateurs  :

  * le *propriétaire* (ou *owner*) noté  `u`
  * le *groupe principal* (ou *group*) noté  `g`
  * un  *autre utilisateur* (ou *other*) noté  `o`

* trois types de permissions  :

    *  *lecture* (caractère *r* si attribué ou *-* sinon)
    *  *écriture* (caractère *w* si attribué  ou *-* sinon)
    *  *exécution* (caractère *x* si attribué  ou *-* sinon)
  
![droits unix](https://upload.wikimedia.org/wikipedia/commons/0/0e/Unix-file-rights.png)

_Source : Wikimedia Commons, Jimbotyson / CC BY-SA (https://creativecommons.org/licenses/by-sa/3.0)_

Pour les répertoires, la signification des permissions est précisée dans ce tableau. Attention, si on a le droit d'écriture sur un répertoire on peut 
supprimer tous les fichiers qu'il contient même ceux dont on n'est pas propriétaire !


|   | Type de permission | pour un répertoire                        |
|---|--------------------|-------------------------------------------|
| r | lecture            | lister le contenu                         |
| w | écriture           | ajouter, supprimer, renommer des fichiers |
| x | exécution          | entrer dedans                             |

En général le nom d'utilisateur figure dans le prompt de l'interpréteur de commandes / shell, mais la commande `id` permet de l'afficher avec la liste des groupes auxquels on appartient :

    junier@fredportable:~$ id
    uid=1000(junier) gid=1000(junier) groupes=1000(junier),4(adm),8(mail),24(cdrom),27(sudo),30(dip),46(plugdev),120(lpadmin),131(lxd),132(sambashare)
    junier@fredportable:~$ sudo apt install pandoc
    [sudo] Mot de passe de junier :

Certaines commandes, comme l'installation de logiciels avec un gestionnaire de paquets comme `apt` ne sont exécutables qu'avec les droits du *superutilisateur* `root`.  Si on appartient au groupe `sudo` (groupe des administrateurs), on peut élever ses droits et agir comme `root`  en préfixant la commande de `sudo`. et en saisissant son mot de passe utilisateur. Certains systèmes permettent de devenir directement `root`  avec la commande `su` en saisissant le mot de passe de `root`.
*L'utilisateur `root` a tous les droits sur le système de fichiers.*


### Exemples de lectures de permissions

On peut afficher les droits d'un fichier avec la commande `ls -l`, en considérant les 10 premiers caractères :

* le premier précise le type de fichier : `d` pour un répertoire et tiret `-` pour un autre fichier
* les 9 caractères suivants dénotent les attributs pour les trois types de permission avec de gauche à droite  le *propriétaire*, le *groupe*, les *autres*. 


* Exemple 1 :
  
        junier@fredportable:~/sandbox$ ls -l histoire-systeme.txt         
        -rw-rw-r-- 1 junier junier 1136 août  15 13:56 histoire-systeme.txt

    Dans cet exemple le fichier  texte  `histoire-systeme.txt` a pour  propriétaire `junier`, pour groupe `junier` et pour droits :
    
|              | Lecture | Écriture | Exécution |   |
|--------------|---------|----------|-----------|---|
| Propriétaire | oui     | oui      | non       |   |
| Groupe       | oui     | oui      | non       |   |
| Autres       | oui     | non      | non       |   | 


* Exemple 2 :

        junier@fredportable:~/sandbox$ ls -l /bin/python3.8
        -rwxr-xr-x 1 root root 5453504 juil. 16 16:00 /bin/python3.8

    Dans cet exemple le fichier  binaire  `/bin/python3.8` a pour propriétaire `root`, pour groupe `root` et pour droits :

|              | Lecture | Écriture | Exécution |   |
|--------------|---------|----------|-----------|---|
| Propriétaire | oui     | oui      | oui       |   |
| Groupe       | oui     | non      | oui       |   |
| Autres       | oui     | non      | oui       |   |


* Exemple 3 : pour afficher les informations détaillées d'un répertoires il faut rajouter l'option `-d`  : 

        junier@fredportable:/var$ ls -l -d mail
        drwxrwsr-x 2 root mail 4096 avril 23 09:32 mail

Dans cet exemple le dossier  `/var/mail` a pour propriétaire `root`, pour groupe `mail` et pour droits :

|              | Lecture | Écriture | Exécution |   |
|--------------|---------|----------|-----------|---|
| Propriétaire | oui     | oui      | oui       |   |
| Groupe       | oui     | oui      | oui       |   |
| Autres       | oui     | non      | oui       |   |

On peut noter que pour le groupe, le droit d'exécution est positionné à `s`, qui correspond au [sgid](https://fr.wikipedia.org/wiki/Permissions_UNIX#Droit_SGID) : tout fichier créé appartient au groupe propriétaire du répertoire.

Attention, si tout membre du groupe `mail` peut écrire dans le répertoire `var`, il peut aussi supprimer un fichier créé par un autre utilisateur même s'il s'agit du superutilisateur `root` :


    junier@fredportable:/var/mail$ ls -l
    total 0
    -rw-r--r-- 1 root mail 0 août  16 10:27 mail_important
    junier@fredportable:/var/mail$ echo 'Bonjour' > mon_message
    junier@fredportable:/var/mail$ ls -l
    total 4
    -rw-r--r-- 1 root   mail 0 août  16 10:27 mail_important
    -rw-rw-r-- 1 junier mail 8 août  16 10:28 mon_message
    junier@fredportable:/var/mail$ rm mail_important
    rm : supprimer 'mail_important' qui est protégé en écriture et est du type « fichier vide » ? y
    junier@fredportable:/var/mail$ ls -l
    total 4
    -rw-rw-r-- 1 junier mail 8 août  16 10:28 mon_message


### Modification des droits / permissions

* Seul le propriétaire d'un fichier (ou répertoire) ou l'utilisateur `root`  peuvent modifier les permissions d'un fichier (ou répertoire) avec la commande `chmod`.
  
    La syntaxe est la suivante, on a noté entre crochets les options facultatives :


        chmod [ugo][+-=][rwx] fichier

    Voici un exemple commenté :

    * Lorsqu'on crée un fichier, par défaut il a les droits de lecture et d'écriture pour l'utilisateur et son groupe principal  et de lecture pour les autres. 


            junier@fredportable:~/bac$ touch fichier
            junier@fredportable:~/bac$ ls -l
            total 0
            -rw-rw-r-- 1 junier junier 0 août  16 11:05 fichier
            junier@fredportable:~/bac$ echo "echo exécution" > fichier
            junier@fredportable:~/bac$ cat fichier 
            echo exécution

    * On ajoute le droite d'exécution à  `fichier` pour son propriétaire et on vérifie que la commande qu'il contient est bien exécutée lorsqu'on écrit `.\fichier` :

            junier@fredportable:~/bac$ chmod u+x fichier
            junier@fredportable:~/bac$ ./fichier 
            exécution
            junier@fredportable:~/bac$ ls -l
            total 4
            -rwxrw-r-- 1 junier junier 16 août  16 11:06 fichier

    * On enlève le droit d'écriture au propriétaire et on vérifie qu'on ne peut plus écrire dans `fichier


            junier@fredportable:~/bac$ chmod u-w fichier 
            junier@fredportable:~/bac$ echo "echo ajout" > fichier
            bash: fichier: Permission non accordée
            junier@fredportable:~/bac$ ls -l
            total 4
            -r-xrw-r-- 1 junier junier 16 août  16 11:06 fichier


    * On ajoute le droit d'écriture au propriétaire et aux autres :


            junier@fredportable:~/bac$ chmod uo+w fichier
            junier@fredportable:~/bac$ ls -l
            total 4
            -rwxrw-rw- 1 junier junier 16 août  16 11:06 fichier

    * On enlève le droit de lecture au propriétaire, à son groupe et aux autres :
    
            junier@fredportable:~/bac$ chmod ugo-r fichier
            junier@fredportable:~/bac$ ls -l
            total 4
            --wx-w--w- 1 junier junier 16 août  16 11:06 fichier
    
    * Pour remettre ce droit de lecture à tous, on peut utiliser le raccourci `a` au lieu de `ugo`  :

            junier@fredportable:~/bac$ chmod a+r fichier 
            junier@fredportable:~/bac$ ls -l
            total 4
            -rwxrw-rw- 1 junier junier 16 août  16 11:06 fichier

    * On positionne tous les droits à `rwx` sur `fichier` pour tous les utilisateurs. On aurait pu écrire `chmod a=rwx fichier`.

            junier@fredportable:~/bac$ chmod ugo=rwx fichier 
            junier@fredportable:~/bac$ ls -l
            total 8
            -rwxrwxrwx 1 junier junier   16 août  16 11:06 fichier


    * On crée un répertoire nommé `repertoire`  avec  deux fichiers. On peut noter qu'un répertoire est toujours créé par défaut avec le droit d'exécution pour tous, car celui-ci permet (ou non) de traverser le répertoire.
  
            junier@fredportable:~/bac$ mkdir repertoire
            junier@fredportable:~/bac$ ls -l -d repertoire/
            drwxrwxr-x 2 junier junier 4096 août  16 11:10 repertoire/
            junier@fredportable:~/bac$ cd repertoire/
            junier@fredportable:~/bac/repertoire$ touch fichier2
            junier@fredportable:~/bac/repertoire$ touch fichier3
            junier@fredportable:~/bac/repertoire$ ls -l
            total 0
            -rw-rw-r-- 1 junier junier 0 août  16 11:10 fichier2
            -rw-rw-r-- 1 junier junier 0 août  16 11:12 fichier3

    * On modifie récursivement les droits sur le répertoire `repertoire` et tous ses fichiers avec  l'option `-R`  dans la commande  `chmod -R ugo=rx repertoire`. On peut vérifier qu'on ne peut plus supprimer les fichiers contenus dans `repertoire`.
  
            junier@fredportable:~/bac$ chmod -R ugo=rx repertoire
            junier@fredportable:~/bac$ ls -l repertoire
            total 0
            -r-xr-xr-x 1 junier junier 0 août  16 11:10 fichier2
            -r-xr-xr-x 1 junier junier 0 août  16 11:12 fichier3
            junier@fredportable:~/bac$ ls -l -d repertoire/
            dr-xr-xr-x 2 junier junier 4096 août  16 11:12 repertoire/
            junier@fredportable:~/bac$ cd repertoire/
            junier@fredportable:~/bac/repertoire$ rm fichier2
            rm : supprimer 'fichier2' qui est protégé en écriture et est du type « fichier vide » ? y 
            rm: impossible de supprimer 'fichier2': Permission non accordée

* Le superutilisateur `root` peut changer le propriétaire d'un fichier avec la commande `chown` ou son groupe principal avec la commande `chgrp` :

            junier@fredportable:~/bac$ ls -l fichier
            -rw-rw-r-- 1 nobody mail 0 août  16 12:05 fichier
            junier@fredportable:~/bac$ sudo chown nobody fichier
            junier@fredportable:~/bac$ ls -l
            -rw-rw-r-- 1 nobody junier    0 août  16 12:05 fichier
            junier@fredportable:~/bac$ sudo chgrp mail  fichier
            junier@fredportable:~/bac$ ls -l
            -rw-rw-r-- 1 nobody mail      0 août  16 12:05 fichier







