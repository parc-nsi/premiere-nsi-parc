

# Définition d'un système d'exploitation

Un *système d’exploitation* est un logiciel, ou ensemble de programmes, qui sert d'interface
entre les programmes exécuté par l'utilisateur et les ressources matérielles d'un
ordinateur.

![Illustration du rôle d'un système d'exploitation](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ed/Operating_system_placement-fr.svg/250px-Operating_system_placement-fr.svg.png)


Il est à la fois :

* une *machine virtuelle* qui présente une interface simplifiée d'accès aux ressources
(processeur, mémoire, périphériques d'entrée/sortie, réseau ...) pour les autres programmes 
et pour l'utilisateur

* un *chef d'orchestre* et un *administrateur* : 
  
  * c'est le premier programme exécuté au démarrage
de l'ordinateur
  *  il gère l'accès concurrent aux ressources par les différents 
programmes (ordonnancement de l'utilisation du processeur par les programmes
en cours d'exécution ou processus, sécurisation de la mémoire) 
ou utilisateurs (droits d'accès du système de fichiers)

* Sitographie : 

  * [Page Wikipedia](https://fr.wikipedia.org/wiki/Syst%C3%A8me_d%27exploitation)
  * [Présentation en video](https://www.lumni.fr/video/comprendre-ce-qu-est-un-systeme-d-exploitation)