

# Attributs du système d'exploitation : le contrôle de l'activité des  programmes

Un programme ne peut être exécuté que si le système d'exploitation l'autorise.
L'exécution d'un programme peut être interrompue par le système d'exploitation,
pour libérer une ressource ou en cas d'erreur, on parle d'interruption système.

Un programme en cours d'exécution s'appelle un *processus* et le système d'exploitation arbitre le partage de temps de calcul du processeur par les processus concurrents. Il jour un rôle *d'ordonnanceur* pour éviter par exemple qu'un processus s'accapare le  processeur.  

Le système d'exploitation maintient une base de temps unique pour tous les
processus et fournit des services de gestion du temps : estampillage, chronologie, attente, réveil.

La commande de *shell*   `ps` permet d'afficher la liste des processus : l'option `U` permet de sélectionner l'utilisateur qui a lancé les processus. S'il s'agit d'un processus qu'on a lancé ou si on est superutilisateur,  peut alors "tuer" le processus avec la commande `kill` suivie du numéro du processus.

    junier@fredportable:~$ ps U
    PID TTY      STAT   TIME COMMAND
    13845 pts/5    S+     0:00 python3
    13900 pts/4    R+     0:00 ps U junier
    junier@fredportable:~$ kill 13845


