

# Attributs du système d'exploitation : le contrôle d'accès aux ressources

Le système d'exploitation est le seul à pouvoir contrôler l'accès aux ressources : processeur, mémoire, périphériques d'entrée/sortie.

La gestion et la sécurisation de la mémoire est une tâche importante, avec un système de *mémoire virtuelle* qui donne à chaque programme l'illusion d'accéder à toute la mémoire.

Des algorithmes permettent d'éviter  les situations d'[interblocage ou étreinte fatale](https://fr.wikipedia.org/wiki/Interblocage).

Un exemple concret d'interblocage peut se produire lorsque deux processus  essayent d'acquérir deux ressources dans un ordre différent. Par exemple avec deux ressources  (M1 et M2),  deux processus (P1 et P2) et la séquence d'opération suivante :

    P1 acquiert M1.
    P2 acquiert M2.
    P1 attend pour acquérir M2 (qui est détenu par P2).
    P2 attend pour acquérir M1 (qui est détenu par P1).

Dans cette situation, les deux processus légers sont définitivement bloqués. 

La commande *shell*   `free` permet d'afficher l'utilisation de la mémoire, l'option `-m` convertit les mesures en megaoctets (Mo).
Dans l'exemple ci-dessous, la mémoire vive disponible est de 3856 Mo,  618 Mo sont utilisés pour les buffers/cache et 254 sont libres soit un total de 3856 - 618 - 254 = 2983 Mo utilisés.  La seconde ligne concerne un espace du disque dur, nommé [swap](https://doc.ubuntu-fr.org/swap), utilisé par le système pour étendre la mémoire vive en mémoire virtuelle.

    junier@fredportable:~/bac$ free -m
                total       utilisé      libre     partagé tamp/cache   disponible
    Mem:           3856        2983         254         302         618         334
    Partition d'échange:        1303        1288          14
