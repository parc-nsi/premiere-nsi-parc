

# Attributs du système d'exploitation : le mode noyau 


Les programmes ne peuvent pas accéder directement aux ressources matérielles
 (mémoire, processeur, périphériques d'entrée/sortie) sinon il y aurait des conflits : par exemple deux programmes pourraient écrire dans la même zone mémoire.


Le système d’exploitation possède un mode d'exécution privilégiée : le *mode noyau*, qui lui donne un accès unique et total aux ressources. Les autres programmes s'exécutent en *mode normal*. Pour accéder aux ressources, ils font appel au système d'exploitation à l'aide de primitives qu'on nomme *appels systèmes*. Pour les systèmes d'exploitation dérivés d'[UNIX](), ces appels systèmes sont normalisés par le standard [POSIX](https://fr.wikipedia.org/wiki/POSIX) pour Portable Operating System Interface.

Le __noyau__ désigne l'ensemble des programmes au coeur du système d'exploitation, qui s'exécutent en particulier au démarrage de l'ordinateur. Par exemple, le noyau du système d'exploitation libre Linux est téléchargeable sur [https://www.kernel.org/](https://www.kernel.org/).