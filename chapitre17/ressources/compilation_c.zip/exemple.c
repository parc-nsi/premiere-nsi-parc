#include "stdlib.h"

int main()
{
int a = 5;
a =  a + 3;
return 0;
} 
