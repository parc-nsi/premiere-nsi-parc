#!/usr/bin/env python
# coding: utf-8

## Exercice 1

# ouverture du fichier
f = open('communes69.csv')
# lecture du fichier ligne par ligne
for ligne in f:
    print(ligne)
#fermeture du fichier
f.close()



def fichier_vers_tab_tuple(fichier, separateur):
    """Prend en paramètres :
    - fichier de type str représentant un chemin d'accès à un fichier texte
    - separateur de type str désignant le séparateur de champs sur une ligne du fichier
    Retourne un tableau de tuples, chaque tuple contenant les différents champs
    d'une ligne du fichier"""



tab_tuple_communes = fichier_vers_tab_tuple('communes69.csv', ',')
assert (len(tab_tuple_communes), tab_tuple_communes[:2]) == (296, [('Affoux', '340', '3', '343'), ('Aigueperse', '246', '1', '247')])


tab_tuple_airports = fichier_vers_tab_tuple('airports-reduit.csv', ';')
assert (len(tab_tuple_airports), tab_tuple_airports[:2]) == (57302,
 [('Total Rf Heliport', '40.07080078125', '-74.93360137939453', '11', 'US'),
 ('Aero B Ranch Airport', '38.704022', '-101.473911', '3435', 'US')])


## Exercice 2

## Exercice 3


def population_minimale(tab):
    """Prend en paramètres :
    - tab un tableau de tuples rassemblant les enregistrements dans 'communes69.csv'
    Retourne un tuple constitué de la population minimale
    et du tableau des villes atteignant ce minimum
    """     




assert(population_minimale(tab_tuple_communes)) == (343, ['Vernay'])


def population_cumul(tab):
    """Prend en paramètres :
    - tab un tableau de tuples rassemblant les enregistrements dans 'communes69.csv'
    Retourne un tuple constitué des cumuls des populations municipale, externe
    et totale des communes 
    """



assert population_moyenne(tab_tuple_communes) == (5955.628378378378, 110.80067567567568, 6066.429054054054)



def population_moyenne(tab):
    """Prend en paramètres :
    - tab un tableau de tuples rassemblant les enregistrements dans 'communes69.csv'
    Retourne un tuple constitué des moyennes des populations municipale, externe
    et totale des communes
    """



assert population_moyenne(tab_tuple_communes) == (5955.628378378378, 110.80067567567568, 6066.429054054054)



def population_lyon(tab):
    """Prend en paramètres :
    - tab un tableau de tuples rassemblant les enregistrements dans 'communes69.csv'
    Retourne la population totale de la ville de Lyon, cumul des populations des 9
    arrondissements
    """


assert(population_lyon(tab_tuple_communes)) == 505094



def population_maximale(tab):
    """Prend en paramètres :
    - tab un tableau de tuples rassemblant les enregistrements dans 'communes69.csv'
    Retourne un tuple constitué de la population maximale
    et du tableau des villes atteignant ce maximum
    """  



assert(population_maximale(tab_tuple_communes)) == (147940, ['Villeurbanne'])


## Exercice 4



def nombre_aeroports_pays(tab, pays):
    """Prend en paramètres:
    - tab un tableau de tuples rassemblant tous les enregistrements contenus dans airports-reduit.csv
    - pays de type str correspondant au code ISO d'un pays
    Retourne un tuple constitué du pays et du  nombre d'aéroports pour ce pays"""





def filtre_altmin_aeroports(tab, altmin):
    """Prend en paramètres:
    - tab un tableau de tuples rassemblant tous les enregistrements contenus dans airports-reduit.csv
    - altmin une altitude minimale en mètres
    Retourne  un tuple constitué de altmin et du nombre d'aéroports d'altitude >= altmin"""




assert filtre_altmin_aeroports(tab_tuple_airports, 1000) == (3280.839895013123, 71)





def filtre_altmax_aeroport(tab, latmin):
    """Prend en paramètres:
    - tab un tableau de tuples rassemblant tous les enregistrements contenus dans airports-reduit.csv
    - latmin une latitude minimale
    Retourne un tuple constitué de latmin, altmax, tab_nom
    où altmax est l'altitude maximale en mètres d'un aeroport de latitude > latmin
    et tab_nom le tableau des noms des aéroports atteignant ce maximum"""



assert filtre_altmax_aeroport(tab_tuple_airports, 0) == (89.999845, 9136.9896, ['Modi'])

