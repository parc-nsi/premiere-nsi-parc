"""
Tests unitaires du module partieB.py
Chaque test unitaire est construit en préfixant la fonction testée de test_
"""
from partieB import *


#%% Tests unitaires de la question 4
def test_decompresse_rle():
    benchmark  = [(b"WWWWWWWWWWWW", b'\x0cW'), (b"WWWWWWAAA",b'\x06W\x03A'), (b"ABCDEFGH",b'\x01A\x01B\x01C\x01D\x01E\x01F\x01G\x01H')]
    for flux, flux_compresse in benchmark:
        assert decompresse_rle(flux_compresse) == flux
    print("Tests réussis pour la fonction decompresse_rle")


#Décommentez la ligne suivante pour exécuter test_decompresse_rle
#test_decompresse_rle()

#%% Tests unitaires de la question 5


def test_compresse_rle():
    benchmark  = [(b"WWWWWWWWWWWW", b'\x0cW'), (b"WWWWWWAAA",b'\x06W\x03A'), (b"ABCDEFGH",b'\x01A\x01B\x01C\x01D\x01E\x01F\x01G\x01H')]
    for flux, flux_compresse in benchmark:
        assert compresse_rle(flux) == flux_compresse
    print("Tests réussis pour la fonction compresse_rle")

#Décommentez la ligne suivante pour exécuter test_decompresse_rle
#test_compresse_rle()
 