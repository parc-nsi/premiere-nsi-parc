from partieA import *

def compresse_rle(flux):
    """
    Paramètre :
        flux de type bytes est un flux d'octets
    Valeur renvoyée :
        flux_compresse de type bytes qui est la compression de flux avec l'algorithme RLE
    """
    courant = flux[0:1]  #pour avoir un bytes
    compteur = 1
    flux_compresse = b''  #de type bytes
    for k in range(1, len(flux)):
       "à compléter"
    return flux_compresse

def decompresse_rle(flux_compresse):
    """
    Paramètre :
        flux_compresse de type bytes est un flux d'octets compressé avec l'algorithme RLE
    Valeur renvoyée :
        flux_sortie de type bytes qui est la décompression de flux_compresse
    """
    flux_sortie = b''
    "à compléter"
    return flux_sortie

def ratio_rle(flux_compresse, flux):
    """
    Paramètre :
        flux de type bytes est un flux d'octets
        flux_compresse de type bytes est un flux d'octets
    Valeur renvoyée :
        un nombre de type float représentant le ratio entre flux et flux_compresse
    """
    "à compléter"


## Code client
if __name__ == "__main__":
    print("Compression RLE d'un texte")
    #à compléter
    