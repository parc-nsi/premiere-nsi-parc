

# Licence logicielle et système d'exploitation


*Une licence de logiciel est un contrat qui octroie un droit d'usage non
exclusif* et par lequel le titulaire des droits d'auteur du logiciel
définit les conditions dans lesquelles ce programme peut être utilisé,
diffusé ou modifié par l'usager.

Contexte historique 
--------------------

De ses débuts jusqu'à l'aube des années 1980, le monde de
l'informatique fut dominé par fabricants de `hardware` tels que IBM.
Dans les années $50$ et $60$, les ordinateurs étaient de gros
calculateurs et l'informatique concernait principalement des
spécialistes (ingénieurs, chercheurs). Les logiciels ou `software`
existaient mais étaient indissociables de la machine sur laquelle ils
étaient installés par le fabricant. L'interopérabilité des programmes,
la normalisation des formats de données n'étaient pas dans l'air du
temps. D'ailleurs, le constructeur ne facturait pas le logiciel qu'il
livrait avec leur machine et fournissait les codes sources aux
utilisateurs afin qu'ils puissent adapter les ressources de l'ordinateur
à leur usage ou rectifier certains bugs.

Dans les années 70, des projets de développement logiciels
d'importance émergèrent comme le projet **UNIX** d'un système
d'exploitation multiutilisateurs (plusieurs comptes utilisateurs mais un
seul utilisateur à la fosi alors que le système MULTICS avait pour
ambition de supporter plusieurs utilisateurs simultanés). Il fut d'abord
développé par Ken Thompson et Denis Ritchie (créateur du lagage C) dans
les laboratoires Bell. Cette entreprise livra le code source à
l'université de Berkeley dont les étudiants améliorèrent le projet qui
fut distribué sous le nom de **Berkeley Software Distribution** (BSD).

A cette époque, les échanges de code sources entre développeurs étaient
naturels et ils furent accélérés par le déploiement du réseau Arpanet
d'interconnexion des universités et centres de recherche, ancêtre de
l'internet.

L'essor de la micro-informatique dans les années $80$, le changement de
profil des usagers (plus forcément des techniciens), firent du logiciel
le facteur dominant du business informatique. Les sociétés d'édition de
logiciels comme Microsoft supplantèrent les fabricants de hardware comme
IBM. Mais la protection de leurs savoir-faire et de leur code ressource
devint un facteur essentiel de leur stratégie de développement. L'époque
des pionniers de l'informatique qui partageaient leurs codes sources et
leurs idées était révolue.

En 1984, **Richard Stallman** démissionnait du MIT, crée la **Free Software Foundation** (FSF) et lançait le projet **GNU** de
développement d'un système d'exploitation libre dont aucun élément ne
serait soumis à une **licence propriétaire** (la première distribution
Unix sans code propriétaire ne fut publiée qu'en 1989). Stallman créa la
première **licence logicielle libre** : la General Public License (GPL).
Le projet GNU aboutit en 1991 au système d'exploitation libre
**GNU/Linux** après incorporation du dernier élément manquant, le noyau
(ou kernel), apporté par Linus Torvalds.

Des références :

-   <http://www.gnu.org/gnu/gnu.html>

-   <http://fr.wikipedia.org/wiki/Unix>


![Carte du libre](https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Carte_conceptuelle_du_logiciel_libre.svg/1024px-Carte_conceptuelle_du_logiciel_libre.svg.png)

_Source :  Wikimedia Commons, René Mérou et autres auteurs_

Les différents types de licences logicielles
--------------------------------------------

On distingue :

-   les **licences propriétaires** :\
    Un éditeur concède à titre non exclusif un droit d'usage sur un
    logiciel dont il conserve les droits de propriété intellectuelle. Un
    **CLUF** (Contrat Licence Utilisateur Final) délimite les conditions
    d'usage du logiciel : limitation du nombre de copies, de postes sur
    lequel le logiciel peut être installé, interdiction de modification
    et de redistribution . En général, le code source n'est pas
    accessible (on parle de logiciel fermé) ....

    


-   les **licences libres** ou **open-source** :\
    elles respectent les quatre libertés fondamentales du logiciel libre
    :

    1.  **liberté d'exécuter le programme, pour tous les usages.**

    2.  **liberté d'étudier le fonctionnement du programme, et de le
        modifier pour l'adapter à ses besoins**

    3.  **liberté de redistribuer des copies.**

    4.  **liberté de redistribuer aux autres des copies de versions
        modifiées**

    Les libertés 2 et 3 nécessitent l'accès au code source.\
    Il ne faut pas confondre licence libre et domaine public : mettre un
    logiciel sous licence libre ne signifie pas abandonner ses droits
    d'auteurs (droit moral inaliénable) mais donner des permissions aux
    usagers qui vont au-delà de ce qu'autorise le droit d'auteur par
    défaut.

    


Attention à *ne pas confondre logiciels libres et gratuits* (double sens
du mot free en Anglais):

-   un **freeware** désigne usuellement un logiciel distribué
    gratuitement, indépendamment de sa licence d'utilisation. Le code
    source n'est pas forcément fourni ; dans ce cas ce n'est pas un
    logiciel libre.

-   un **shareware** désigne un logiciel distribué gratuitement et
    librement pendant une durée ou un nombre d'utilisations qui sont
    fixées par l'auteur. Au delà de ce délai il faut payer des royalties
    et le code source n'est pas fourni donc ce n'est pas un logiciel
    libre.

Références :

-   <http://www.cndp.fr/savoirscdi/societe-de-linformation/cadre-reglementaire/le-coin-du-juriste/logiciel-libre-et-gratuiciel.html>

-   <http://www.gnu.org/philosophy/categories.html> et
    <http://www.gnu.org/philosophy/philosophy.html>

Licences de logiciels libres 
-----------------------------

On distingue deux types de licences libres :

1.  Les **licences avec copyleft** :

    Le copyleft ( gauche d'auteur , jeu de mots sur copyright), n'est
    pas l'abandon du copyright (droits patrimoniaux) mais au contraire
    s'appuie dessus pour rendre libre un programme (respect des 4
    libertés fondamentales) en obligeant toutes les versions modifiées à
    être libres également et redistribuées sous la même licence. Ainsi
    le logiciel (ou l'oeuvre numérique) sera éternellement libre. La
    licence `GPL` (General Public License) créée par Richard Stallman en
    1989 fut la première licence libre avec copyleft. La licence
    `CeCill` créée par l'INRIA est une adaptation de la licence GPL au
    droit français. La licence `Creative Commons` CC BY-SA 3.0,
    paternité et partage à l'identique, est une licence libre avec
    copyleft pour les oeuvres numériques (image, video ...).

    Il existe des formes plus ou moins fortes de copyleft. Ainsi si on
    inclut du code sous license GPL dans un autre, le programme hybride
    créé est contaminé et doit être distribué sous licence GPL. La
    license **LGPL** présente un copyleft plus faible : du code sous
    cette license cette license peut être inclus dans un code sous une autre license
    sans que le programme hybride soit nécessairement sous license LGPL.
    C'est utile pour développer des bibliothèques de fonctions.

2.  Les **licences sans copyleft** :

    L'utilisateur peut redistribuer et modifier le logiciel, mais aussi
    ajouter des restrictions et distribuer une version modifiée sous
    licence propriétaire. On parle aussi de licence permissive . La
    première licence libre sans copyleft fut la licence `BSD` pour le
    distributions de logiciels créés par l'université de Berkeley. *La
    licence de Python est une licence libre sans copyleft*. Ce sont des
    licences compatibles avec la GPL mais la réciproque est fausse.


Exemple des systèmes d'exploitation 
-----------------------------------

![Arbre généalogique des systèmes UNIX](https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Unix_history-simple.svg/1024px-Unix_history-simple.svg.png)


![Arbre généalogique des systèmes Windows](https://upload.wikimedia.org/wikipedia/commons/3/39/Microsoft_timeline_of_operating_systems_2.png)


* Systèmes d'exploitation propriétaires :  Windows et partiellement MacOS (une partie UNIX est sous licence BSD)
  
* Systèmes d'exploitation libres :  de nombreuses distributions basées sur le noyau Linux, système dérivé d'UNIX : Debian, Ubuntu, Fedora, ArchLinux .... .

:::exercice

1. Lequel de ces systèmes d\'exploitation est sous licence libre ?

***Réponses***

__A)__ Android  __B)__ Linux  __C)__ Windows  __D)__ MacOS

2. Une et une seule de ces affirmations est **fausse**. Laquelle ?

***Réponses***

__A)__ Un système d\'exploitation libre est la plupart du temps gratuit

__B)__ Je peux contribuer à un système d'exploitation libre

__C)__ Il est interdit d\'étudier un système d'exploitation propriétaire

__D)__ Un système d\'exploitation propriétaire est plus sécurisé

:::